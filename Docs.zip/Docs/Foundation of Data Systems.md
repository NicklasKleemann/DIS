# Foundations of Data Systems

> **Core Question:** What makes a data system "good"? We evaluate systems on three pillars: **Reliability**, **Scalability**, and **Maintainability**.

---

## 1. Reliability — Surviving Failure

A reliable system continues to work correctly even when things go wrong. The goal isn't to prevent all failures—it's to **tolerate faults gracefully**.

### Types of Faults

| Fault Type | Example | Mitigation Strategy |
|------------|---------|---------------------|
| **Hardware** | Disk crash, power outage | Redundancy (RAID, multi-AZ deployments) |
| **Software** | Linux kernel crash from 2012 leap second bug | Process isolation, extensive testing |
| **Human** | Typo in production config takes down service | Sandboxing, validation layers, staging environments |

**Key insight:** Human error is the #1 cause of outages. Design systems that make it hard to do the wrong thing.

---

## 2. Scalability — Handling Growth

Scalability is about answering: *"If load increases by X, what breaks first?"*

To discuss scalability, you need **load parameters**—the specific metrics that define your system's workload.

### Case Study: Twitter's Timeline Problem

Twitter has two core operations with wildly different frequencies:

| Operation | Request Rate | Description |
|-----------|--------------|-------------|
| `PostTweet` | ~4.6k/sec | User publishes a tweet |
| `HomeTimeline` | ~300k/sec | User views their feed |

Reads outnumber writes **65:1**. This asymmetry drives architecture decisions.

---

### 🧠 Reasoning Chain: "Why does each approach fail?"

Follow this step-by-step to understand *why* Twitter needed multiple approaches:

#### Step 1: Start with the naive solution (Pull Model)

```
User tweets → Insert into global Tweets table
User loads timeline → JOIN tweets WHERE author IN (people I follow)
```

**Walk through the failure:**
1. I follow 500 people
2. Each person has tweeted 1000 times
3. Timeline query must scan 500,000 tweets, sort by time, return top 100
4. This query runs 300,000 times per second (timeline loads)
5. ❌ **Database melts** — reads are too expensive at scale

**Conclusion:** Pull fails because **read cost scales with data size**, and reads happen 65x more than writes.

#### Step 2: Flip the cost to writes (Push Model)

```
User tweets → Copy this tweet to every follower's personal timeline cache
User loads timeline → Just read their pre-built cache
```

**Walk through the improvement:**
1. User tweets once
2. System writes to 500 followers' caches (500 writes)
3. Each timeline load is now a simple cache read (O(1))
4. ✅ Reads are now instant!

**But wait... walk through the edge case:**
1. Celebrity with 100M followers tweets
2. System must perform 100M cache writes
3. Tweet takes minutes to propagate
4. ❌ **Write queue explodes** — celebrities break the system

**Conclusion:** Push fails for celebrities because **write cost scales with follower count**.

#### Step 3: Combine based on user type (Hybrid)

```
Regular user tweets → Push to followers' caches (fast propagation)
Celebrity tweets → Just insert to global table (pull at read time)
Timeline load → Merge personal cache + pull celebrity tweets
```

**Why this works:**
1. 99% of users have <10k followers → Push is cheap
2. Celebrities are rare → Pull queries are rare
3. ✅ Both read and write costs stay manageable

---

### Summary Table: Fan-Out Approaches

| Approach | Write Cost | Read Cost | Breaks When... |
|----------|------------|-----------|----------------|
| Pull | O(1) | O(followers × tweets) | Reads spike (always) |
| Push | O(followers) | O(1) | Celebrities tweet |
| Hybrid | Medium | Medium | Complexity grows |

---

### Measuring Performance: Percentiles, Not Averages

**Don't use averages.** A single 30-second timeout skews the mean and hides real user experience.

Use **percentiles**:
- **p50 (median):** Half of requests are faster than this
- **p95:** 95% of requests are faster
- **p99:** The "tail latency"—often your most valuable users (they have the most data)

> *Example:* p95 = 1.5s means 95% of users experience sub-1.5s response times. The remaining 5% are your optimization target.

**Latency vs Response Time:**
- **Response Time** = What the user experiences (network + queue + processing)
- **Latency** = Time spent waiting in queue before processing starts

---

## 3. Maintainability — Developer Experience

A maintainable system is one that doesn't make engineers miserable.

| Aspect | Goal | Example |
|--------|------|---------|
| **Operability** | Easy to run in production | Dashboards that alert before disk fills up |
| **Simplicity** | Minimize cognitive load | ORM hides raw SQL complexity |
| **Evolvability** | Easy to change | Schema migrations without downtime |

---

## 4. Data Models: SQL vs Document

### The Core Tradeoff

| | Relational (SQL) | Document (NoSQL) |
|---|---|---|
| **Mental Model** | Excel spreadsheet with strict columns | Folder of Word docs (each can differ) |
| **Structure** | Normalized tables linked by foreign keys | Denormalized JSON trees |
| **Reads** | JOINs across tables | Single document fetch |
| **Updates** | Change once, reflected everywhere | Must update every copy |

---

### 🧠 Reasoning Chain: "Which database should I use?"

**Start with these questions:**

#### Question 1: "How is my data shaped?"

```
Does my data look like a TREE? (one root, nested children)
  → Example: User profile with nested positions, education, skills
  → Document DB is natural fit

Does my data look like a GRAPH? (many-to-many connections)
  → Example: Users follow users, products have categories, orders link to products
  → Relational DB handles joins well
```

#### Question 2: "How often do I update shared data?"

```
Do many records share the same value that might change?
  → Example: 1000 users have job title "Software Developer"
  → Company renames it to "Software Engineer"
  
  SQL: UPDATE positions SET title = 'Software Engineer' WHERE title = 'Software Developer'
  → ✅ One query, done

  Document: Must find and update every user document containing that title
  → ❌ 1000 updates, error-prone
```

**Rule:** If shared data changes frequently → SQL

#### Question 3: "What does my typical query look like?"

```
Do I usually fetch ONE complete entity?
  → "Give me everything about User #123"
  → Document: GET /users/123 (instant, one fetch)
  → SQL: SELECT + JOIN + JOIN + JOIN... (multiple tables)
  → ✅ Document wins

Do I usually fetch ACROSS entities?
  → "Find all users in Engineering who joined after 2020"
  → SQL: Simple WHERE clause across normalized table
  → Document: Must scan all documents
  → ✅ SQL wins
```

#### Decision Flowchart

```
START: What are you building?
│
├─→ User profiles, blog posts, product catalogs
│   └─→ Data is self-contained? → YES → Document DB
│
├─→ Banking, inventory, e-commerce orders
│   └─→ Need transactions + relationships? → YES → SQL
│
├─→ Social network, recommendation engine
│   └─→ Many-to-many relationships? → YES → SQL (or Graph DB)
│
└─→ Rapid prototyping, schema still changing
    └─→ Need flexibility? → YES → Document DB (migrate later if needed)
```

---

### Comparison Table

| Feature | Relational (SQL) | Document (NoSQL) |
|---------|------------------|------------------|
| Data Structure | Tables & Rows (Normalized) | JSON/XML Tree (Denormalized) |
| Schema | Strict (Schema-on-Write) | Flexible (Schema-on-Read) |
| Querying | JOINs required | Get by ID |
| Consistency | Strong (ACID) | Eventually consistent |
| Best For | Transactions, relationships | Profiles, content, speed |

---

## 5. CAP Theorem — The Partition Problem

### 🧠 Reasoning Chain: "What happens during a network partition?"

#### Setup: Two database nodes, normally synced

```
Normal state:
  Client writes x=5 to Node A
  Node A syncs to Node B
  Client reads from Node B, gets x=5
  ✅ Everything works
```

#### The Problem: Network cable is cut

```
Partition state:
  Client writes x=5 to Node A
  Node A cannot reach Node B (cable cut)
  Client reads from Node B...
  
  Node B has a choice:
```

#### The Two Options (pick one)

**Option CP — Prioritize Consistency:**
```
Node B thinks: "I can't reach Node A. The data might have changed."
Node B responds: "ERROR: Cannot guarantee correct data"
Result: 
  ✅ Data is always correct (no stale reads)
  ❌ System is unavailable during partition
Use when: Banking, inventory (wrong data = real money lost)
```

**Option AP — Prioritize Availability:**
```
Node B thinks: "I can't reach Node A, but I'll serve what I have."
Node B responds: "x=4" (last known value, might be stale)
Result:
  ✅ System always responds
  ❌ Data might be wrong/outdated
Use when: Social media, caching (stale tweet < system down)
```

#### Visual

```mermaid
graph TD
    subgraph "During Network Partition"
    C[Client] -->|Write x=5| A[Node A]
    C -->|Read x=?| B[Node B]
    A -.-x|"❌ Cable Cut"| B
    end
    
    B --> CP["CP: Return ERROR<br/>(consistent but unavailable)"]
    B --> AP["AP: Return x=4<br/>(available but stale)"]
```

#### Key Insight

> ⚠️ CAP only applies **during partitions**. In normal operation, you can have consistency AND availability. The theorem is about what you **sacrifice** when things go wrong.

---

## Quick Reference

### Exam Problem-Solving Templates

#### Template 1: "Analyze this system's scalability"

```
1. Identify load parameters
   → What operations? (reads vs writes)
   → What's the ratio?

2. Find the bottleneck
   → Which operation dominates?
   → What does that operation cost?

3. Propose optimization
   → Can you shift cost from the hot path?
   → Example: Push shifts cost from reads to writes
```

#### Template 2: "SQL or NoSQL for this use case?"

```
1. Data shape
   → Tree-like (nested) → Document
   → Graph-like (relationships) → SQL

2. Update patterns
   → Shared data changes often → SQL
   → Self-contained records → Document

3. Query patterns
   → Fetch whole entities → Document
   → Query across entities → SQL
```

#### Template 3: "CP or AP for this system?"

```
1. What's the cost of wrong data?
   → Money/legal/safety → CP (consistency)
   → User inconvenience → AP (availability)

2. What's the cost of downtime?
   → Revenue per minute down → Favors AP
   → Can users retry later? → Favors CP
```

---

### Exam-Style Questions

1. **"Explain Twitter's fan-out problem and solutions."**
   - Pull: cheap writes, expensive reads → fails at 300k reads/sec
   - Push: instant reads, expensive writes → fails for celebrities
   - Hybrid: push for regular users, pull for celebrities

2. **"Why percentiles over averages for latency?"**
   - Averages hide outliers
   - p99 often represents your most valuable users
   - Tail latency optimization has disproportionate business impact

3. **"When to use Document over Relational?"**
   - Data is self-contained (user profiles, blog posts)
   - Rarely need cross-document joins
   - Need schema flexibility for rapid iteration